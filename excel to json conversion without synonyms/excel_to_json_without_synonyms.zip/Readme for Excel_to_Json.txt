Excel to Json conversion:

Inputs: excelfile path, jsonfile path, customer id, request type, language

Output: josn format 


1. Create the excel file, refer: products_detail 

2. Create json file to write json for the excel format.

3. Run the command 'pip install openpyxl'

4. Run the command 'python excel_to_json.py'

5. Give the path for excel file in ".xlsx" extension, Ex: 'D:\products_detail.xlsx'

6. Give the path for json file. Ex: 'D:\json_product.json'

7. Json format will be updated in the json file path provided.   